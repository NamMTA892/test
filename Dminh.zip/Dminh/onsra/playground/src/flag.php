<?php
$FLAG = "MSEC{NemNemForFun}";